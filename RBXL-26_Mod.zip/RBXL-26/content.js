// ======== SET EXTENSION ICON ========
// This will change the toolbar icon to image1.png
if (chrome.action && chrome.action.setIcon) {
    chrome.action.setIcon({ path: "image1.png" });
}
window.addEventListener('load', () => {

    /* ============================
       VIDEO BACKGROUND
    ============================ */
    if (!document.getElementById('rbxl-video-bg')) {
        const video = document.createElement('video');
        video.id = 'rbxl-video-bg';
        video.src = chrome.runtime.getURL('video.mp4');
        video.loop = true;
        video.muted = true;
        video.playsInline = true;
        video.preload = 'auto';
        Object.assign(video.style, {
            position: 'fixed',
            top: '0',
            left: '0',
            width: '100vw',
            height: '100vh',
            zIndex: '-1000',
            objectFit: 'cover',
            pointerEvents: 'none'
        });
        document.body.appendChild(video);
        video.addEventListener('canplaythrough', () => video.play().catch(() => {}));
    }

    /* ============================
       PERSISTENT BACKGROUND MUSIC
    ============================ */
    if (!document.getElementById('rbxl-music-bg')) {
        const music = document.createElement('audio');
        music.id = 'rbxl-music-bg';
        music.src = chrome.runtime.getURL('Music.mp3');
        music.loop = true;
        music.volume = 0.5;
        music.controls = false;
        music.preload = 'auto';
        music.muted = true;
        document.body.appendChild(music);
        music.play().catch(() => {});

        function unmuteMusic() {
            music.muted = false;
            music.play().catch(() => {});
            window.removeEventListener('click', unmuteMusic);
        }
        window.addEventListener('click', unmuteMusic);
    }

    /* ============================
       CONSTANTS
    ============================ */
    const DARK_TO_BLUE = 'rgb(25, 26, 31)';
    const DARK_TO_TRANSPARENT = 'rgb(18, 17, 22)';
    const BLUE_COLOR = 'rgb(10, 25, 60)';
    const TRANSPARENT = '#12121500';

    /* ============================
       INJECT CSS
    ============================ */
    if (!document.getElementById('rbxl-style')) {
        const style = document.createElement('style');
        style.id = 'rbxl-style';
        style.textContent = `
            [data-testid="game-carousel-scroll-bar"] { background-color: transparent !important; }
            [data-testid="game-carousel-scroll-bar"] .spacer { background-color: transparent !important; }
            [data-testid="game-carousel-scroll-bar"] .arrow { background-color: transparent !important; }

            button, input[type="button"], input[type="submit"], a.btn, a.button, a.btn-primary { border-radius: 0 !important; }
            .thumbnail-2d-container.game-card-thumb-container,
            .thumbnail-2d-container.game-card-thumb,
            .thumbnail-2d-container.brief-game-icon { border-radius: 0 !important; }
        `;
        document.head.appendChild(style);
    }

    /* ============================
       CONTENT BACKGROUND
    ============================ */
    function fixContentBackground() {
        const content = document.querySelector('.dark-theme .content');
        if (content) content.style.setProperty('background-color', TRANSPARENT, 'important');
    }

    /* ============================
       COLOR REPLACER
    ============================ */
    function replaceColors() {
        document.querySelectorAll('*').forEach(el => {
            if (el.closest('.dark-theme .content')) return;
            const bg = getComputedStyle(el).backgroundColor;
            if (bg === DARK_TO_BLUE) el.style.setProperty('background-color', BLUE_COLOR, 'important');
            if (bg === DARK_TO_TRANSPARENT) el.style.setProperty('background-color', TRANSPARENT, 'important');
        });
    }

    fixContentBackground();
    replaceColors();

    const observer = new MutationObserver(() => {
        fixContentBackground();
        replaceColors();
    });
    observer.observe(document.body, { childList: true, subtree: true });

    /* ============================
       MUSIC TOGGLE UI
    ============================ */
    if (!document.getElementById('rbxl-music-ui')) {
        const ui = document.createElement('div');
        ui.id = 'rbxl-music-ui';
        Object.assign(ui.style, {
            position: 'fixed',
            bottom: '20px',
            right: '20px',
            zIndex: '9999',
            background: 'rgba(0,0,0,0.6)',
            color: 'white',
            padding: '8px 12px',
            borderRadius: '8px',
            cursor: 'pointer',
            fontFamily: 'Arial, sans-serif',
            userSelect: 'none',
            fontSize: '14px',
            boxShadow: '0 0 8px rgba(0,0,0,0.5)'
        });
        ui.innerText = '🎵 On';
        document.body.appendChild(ui);

        const music = document.getElementById('rbxl-music-bg');
        ui.addEventListener('click', () => {
            if (!music) return;
            music.muted = !music.muted;
            ui.innerText = music.muted ? '🎵 Off' : '🎵 On';
        });
    }

    /* ============================
       HOVER & CLICK AUDIO FOR ANY CLICKABLE ELEMENT
    ============================ */
    const hoverAudioSrc = chrome.runtime.getURL('hvr.mp3');
    const arrowClickSrc = chrome.runtime.getURL('rrw.mp3');
    const buttonClickSrc = chrome.runtime.getURL('pss.mp3');

    const hoverAudio = document.getElementById('rbxl-hover-audio') || (() => {
        const a = document.createElement('audio'); a.id = 'rbxl-hover-audio'; a.src = hoverAudioSrc; a.preload = 'auto'; a.volume = 0.4; document.body.appendChild(a); return a;
    })();

    const arrowAudio = document.getElementById('rbxl-arrow-audio') || (() => {
        const a = document.createElement('audio'); a.id = 'rbxl-arrow-audio'; a.src = arrowClickSrc; a.preload = 'auto'; a.volume = 0.5; document.body.appendChild(a); return a;
    })();

    const buttonAudio = document.getElementById('rbxl-button-audio') || (() => {
        const a = document.createElement('audio'); a.id = 'rbxl-button-audio'; a.src = buttonClickSrc; a.preload = 'auto'; a.volume = 0.5; document.body.appendChild(a); return a;
    })();

    function isClickable(el) {
        return (
            el.tagName === 'BUTTON' ||
            (el.tagName === 'A' && el.href) ||
            el.getAttribute('role') === 'button' ||
            el.hasAttribute('onclick') ||
            (el.tabIndex >= 0)
        );
    }

    function addHoverEffects() {
        document.querySelectorAll('*').forEach(el => {
            if (!isClickable(el)) return;
            if (el.getAttribute('data-rbxl-hover')) return;
            el.setAttribute('data-rbxl-hover', 'true');
            el.style.transition = 'transform 0.08s ease';

            el.addEventListener('mouseenter', () => {
                hoverAudio.currentTime = 0;
                hoverAudio.play().catch(() => {});
                el.style.transform = 'scale(1.03)';
            });

            el.addEventListener('mouseleave', () => {
                el.style.transform = 'scale(1)';
            });
        });
    }

    function addClickSounds() {
        document.querySelectorAll('*').forEach(el => {
            if (!isClickable(el)) return;

            if (el.closest('.icon-games-carousel-left, .icon-games-carousel-right')) {
                if (!el.getAttribute('data-rbxl-click')) {
                    el.setAttribute('data-rbxl-click', 'true');
                    el.addEventListener('click', () => {
                        arrowAudio.currentTime = 0;
                        arrowAudio.play().catch(() => {});
                    });
                }
            } else {
                if (!el.getAttribute('data-rbxl-btn-click')) {
                    el.setAttribute('data-rbxl-btn-click', 'true');
                    el.addEventListener('click', () => {
                        buttonAudio.currentTime = 0;
                        buttonAudio.play().catch(() => {});
                    });
                }
            }
        });
    }

    // First run
    addHoverEffects();
    addClickSounds();

    // Observe DOM changes for SPA support
    const hoverObserver = new MutationObserver(addHoverEffects);
    hoverObserver.observe(document.body, { childList: true, subtree: true });

    const clickObserver = new MutationObserver(addClickSounds);
    clickObserver.observe(document.body, { childList: true, subtree: true });

});
